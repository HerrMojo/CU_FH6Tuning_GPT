# FH6GPT Tune Lab

A static browser-based Forza Horizon tuning calculator for grip, drift, and drag builds across pavement, mixed, and offroad surfaces.

## What it does

- Generates game-facing recommendations for:
  - Tire pressure
  - Gearing
  - Alignment
  - Anti-roll bars
  - Springs and ride height
  - Damping
  - Aero
  - Brakes
  - Differential
- Supports D through X class scaling.
- Supports FWD, RWD, and AWD drivetrains.
- Supports front, mid, and rear engine layout assumptions.
- Supports body type, suspension type, tire compound, torque, horsepower, weight, and front weight percentage inputs.
- Adds a handling-bias selector: Stable / Neutral / More rotation.
- Supports separate front and rear aero availability.
- Includes a phase-based diagnostic system for braking, turn-in, mid-corner, exit, bump, and gearing problems.
- Saves tunes locally in the browser.
- Exports tune JSON.
- Copies a readable tune summary to the clipboard.
- Includes a cyberpunk neon theme using `#2CFF05`, `#FFC4FB`, `#51158C`, and `#00F0FF`.

## Notes on values

The app displays main values in Forza-style units:

- Anti-roll bars: 0 to 100 style setting
- Springs: lb/in
- Ride height: inches, front and rear
- Damping: 1 to 20, front/rear rebound and bump
- Differential: percentages
- Tire pressure: PSI

The app still stores some internal normalized ratios for calculation and JSON export, but the visible tune cards prioritize game-facing values.

## Running locally

Open `index.html` directly in a browser, or run a simple local server:

```bash
python3 -m http.server 8080
```

Then open:

```text
http://localhost:8080
```

## Publishing

This project is static HTML/CSS/JavaScript. It can be published with GitHub Pages by uploading the files to the repository root and enabling Pages from `main / root`.

## Reference-inspired improvements

This build adds reference-inspired ideas without copying any third-party tuning formulas directly:

- More complete 9-tab tuning coverage
- More diagnostic symptom cards
- Torque-influenced differential behavior
- Handling-bias control
- Body type, suspension type, engine location, and aero availability inputs
- Gear redline speed visualization
- Copy-to-clipboard output
- Phase-based tuning workflow notes

All tunes are starting points. Drive, diagnose by phase, change one setting, then retest.

## Font

The app now uses an OpenDyslexic-first font stack:

`OpenDyslexic`, `OpenDyslexicAlta`, `Atkinson Hyperlegible`, then system UI fallbacks.

No font files are bundled in this project. If OpenDyslexic is installed on the device, the browser will use it. Otherwise, the app falls back to a readable system font.

## Background style

This variant uses a softer purple-to-magenta fade background inspired by the provided reference image, while keeping the cyberpunk UI accents and OpenDyslexic-first font stack.

## Bold fade variant

This variant pushes the background toward a more saturated, bolder, slightly darker blue-purple-magenta fade while keeping the OpenDyslexic-first font stack and neon UI accents.

## Game-facing unit fix

This revision maps anti-roll bars to Forza’s 1–65 setting range instead of showing percentage-style values. Aero recommendations now display estimated pounds of downforce for front and rear aero rather than raw internal ratios.

## Aero range inputs

The app now includes front/rear aero min and max fields in pounds. Enter the minimum and maximum shown by the Forza aero slider for the car, and the calculator will map its internal aero balance to a usable pound value inside that range.

## Tire size input

The gearbox calculator now accepts tire sizes in the standard game/automotive format, such as `225/65R17`, `225 65r17`, or `225-65-17`. The app converts that to tire diameter and circumference internally for gear-speed math, so players no longer need to manually look up tire diameter.

## Tuning type label update

The Grip, Drift, and Drag labels in the tuning type cards use a larger font size for easier scanning.

## SQL export

Use **Export SQL** to download the current tune as a `.sql` file. The file creates a `forza_tunes` table if needed and inserts/replaces the tune by ID. It is designed for SQLite first:

```bash
sqlite3 forza_tunes.db < exported-tune.sql
```

The export includes common searchable columns plus a full `tune_json` backup column so future app fields are not lost.
